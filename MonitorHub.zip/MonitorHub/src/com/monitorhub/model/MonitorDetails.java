/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.monitorhub.model;

/**
 *
 * @author Prajol
 */
public class MonitorDetails {
    private String brandName;
    private String modelName;
    private String modelType;
    private int stock;
    


    // Constructor
    public MonitorDetails(String brandName, String modelName, String modelType, int stock) {
        this.brandName = brandName;
        this.modelName = modelName;
        this.modelType = modelType;
        this.stock = stock;
    }

    // Getters
    public String getBrandName() {
        return brandName;
    }

    public String getModelName() {
        return modelName;
    }

    public String getModelType() {
        return modelType;
    }

    public int getStock() {
        return stock;
    }
}


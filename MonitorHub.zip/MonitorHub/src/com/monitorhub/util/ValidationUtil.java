package com.monitorhub.util;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Prajol
 */


import javax.swing.table.DefaultTableModel;



public class ValidationUtil {

    // Validate if the same modelName and monitorType already exist in the table
    public static boolean isDuplicateModelType(String modelName, String monitorType, DefaultTableModel tableModel) {
        int rowCount = tableModel.getRowCount();
        for (int i = 0; i < rowCount; i++) {
            if (modelName.equalsIgnoreCase(tableModel.getValueAt(i, 1).toString()) &&
                monitorType.equalsIgnoreCase(tableModel.getValueAt(i, 2).toString())) {
                return true;
            }
        }
        return false;
    }
}



